from django.db import models

# Create your models here.
class Savedata(models.Model):
    fname = models.CharField(max_length=50)
    lname = models.CharField(max_length=50)
    addr = models.CharField(max_length=50)
    mnum = models.CharField(max_length=50)
    username = models.CharField(max_length=50)
    pwd = models.CharField(max_length=50)
    cpwd = models.CharField(max_length=50)

