from django.apps import AppConfig


class PgadminConfig(AppConfig):
    name = 'pgadmin'
