from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
 

# Create your views here.
def index(request):
    return render(request, "employee.html")
def add_employee(request):
    return render(request, "add_employee.html")


def Savedata(request):

    if request.method=='POST':
        
        fname = request.POST['fname']
        lname = request.POST.get('lname')
        addr = request.POST.get('addr')
        mnum = request.POST.get('mnum')
        username = request.POST.get('username')
        pass1 = request.POST.get('pass1')
        pass2 = request.POST.get('pass2')

        en=savedata(fname=fname,lname=lname,addr=addr,mnum=mnum,username=username,pwd=pass1,cpwd=pass2)
        en.save()

        return render(request, '')



    return render(request,'add_employee.html')
    
  










 