
from django.contrib import admin
from .models import Savedata


admin.site.register(Savedata)
# Register your models here.
