from django.urls import path
from . import views

urlpatterns =[
    path('home',views.index, name='index'),
    path('user_home', views.user_home, name= 'user_home'),
    path('booking_form', views.booking_form, name = 'booking_form')
]